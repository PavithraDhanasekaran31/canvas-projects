document.querySelectorAll('.priority-select').forEach(select => {
    select.addEventListener('change', function () {
        const card = this.closest('.task-card');

        if (this.value === 'URGENT') {
            card.style.backgroundColor = 'red';
            card.style.color = 'white';
        } else {
            card.style.backgroundColor = '';
            card.style.color = '';
        }
    });
});
