document.getElementById("taskForm").addEventListener("submit", function(e) {
    e.preventDefault();
    let valid = true;

    function error(id, msg) {
        document.getElementById(id).innerText = msg;
        if (msg) valid = false;
    }

    error("nameError", name.value ? "" : "Task name required");
    error("descriptionError", description.value ? "" : "Description required");
    error("assignedError", assignedTo.value ? "" : "Assigned person required");
    error("dateError", dueDate.value ? "" : "Due date required");
    error("statusError", status.value ? "" : "Status required");

    if (valid) {
        alert("Task validated successfully!");
        this.reset();
    }
});
