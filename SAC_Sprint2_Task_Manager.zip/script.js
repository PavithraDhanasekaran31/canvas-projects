// Task class definition
class Task {
    constructor(id, name, description, assignedTo, dueDate, status) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.assignedTo = assignedTo;
        this.dueDate = dueDate;
        this.status = status;
    }
}

// TaskManager class definition
class TaskManager {
    constructor() {
        this.tasks = [];
        this.currentId = 1;
    }

    addTask(name, description, assignedTo, dueDate, status) {
        const task = new Task(
            this.currentId++,
            name,
            description,
            assignedTo,
            dueDate,
            status
        );
        this.tasks.push(task);
        return task;
    }

    deleteTask(id) {
        this.tasks = this.tasks.filter(task => task.id !== id);
    }
}

const taskManager = new TaskManager();
const taskList = document.getElementById("taskList");

document.getElementById("taskForm").addEventListener("submit", function(e) {
    e.preventDefault();

    if (!name.value || !description.value || !assignedTo.value || !dueDate.value || !status.value) {
        alert("Please fill all fields");
        return;
    }

    const task = taskManager.addTask(
        name.value,
        description.value,
        assignedTo.value,
        dueDate.value,
        status.value
    );

    displayTask(task);
    this.reset();
});

function displayTask(task) {
    const item = document.createElement("div");
    item.className = "list-group-item";
    item.id = `task-${task.id}`;

    item.innerHTML = `
        <h5>${task.name}</h5>
        <p>${task.description}</p>
        <p><strong>Assigned:</strong> ${task.assignedTo}</p>
        <p><strong>Due:</strong> ${task.dueDate}</p>
        <span class="badge bg-secondary">${task.status}</span>
        <button class="btn btn-danger btn-sm float-end" onclick="removeTask(${task.id})">Delete</button>
    `;

    taskList.appendChild(item);
}

function removeTask(id) {
    taskManager.deleteTask(id);
    document.getElementById(`task-${id}`).remove();
}
